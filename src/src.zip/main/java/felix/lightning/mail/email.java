package felix.lightning.mail;

import javax.activation.FileTypeMap;
import javax.activation.MimetypesFileTypeMap;

import felix.lightning.lightninglogin.Lightning;
import felix.lightning.lightninglogin.emali;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.Arrays;
import java.util.Properties;
import java.util.UUID;
import javax.mail.*;
import javax.mail.internet.*;

public class email {
    private static String host;
    private static String database;
    private static String username;
    private static String password;
    private static Connection connection;
    private static int EmailNum;

    static FileConfiguration config = Lightning.getIns().getConfig();


    public static void main(String ardss, String code, UUID uuid, Player player) throws UnsupportedEncodingException {

        FileConfiguration config = Lightning.getIns().getConfig();
        connecteddatabase();
        String sjr = ardss + "@qq.com";

        try {
            String query = "SELECT * FROM playerinfo WHERE email = ?"; // Use '?' as placeholders for values
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, sjr); // Set the UUID value for the first placeholder
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // If the query returns a row, it means the player exists in the database
                //邮箱在数据库中！
                emali.player.sendMessage("================");
                emali.player.sendMessage("§b" + config.getString("emailindatabase"));
                emali.player.sendMessage("================");
                emali.player.kickPlayer("§c" + config.getString("emailindatabase"));
                connection.close();
                return;
            }

            resultSet.close(); // Close the ResultSet after use
            statement.close(); // Close the PreparedStatement after use
        } catch (SQLException e) {
            Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
        } finally {
            try {
                connection.close(); // Close the database connection after use
            } catch (SQLException e) {
                // Handle the error, if any, during closing the connection
                e.printStackTrace();
            }
        }

        if (connection != null) {
            try {
                String query = "SELECT * FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, uuid.toString()); // Set the UUID value for the first placeholder
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // If the query returns a row, it means the player exists in the database
                    //玩家在数据库中！
                    emali.player.sendMessage("================");
                    emali.player.sendMessage("§b" + config.getString("indatabase"));
                    emali.player.sendMessage("================");
                    emali.player.kickPlayer("§c" + config.getString("indatabase"));
                    connection.close();
                    return;
                }

                resultSet.close(); // Close the ResultSet after use
                statement.close(); // Close the PreparedStatement after use
            } catch (SQLException e) {
                Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
            } finally {
                try {
                    connection.close(); // Close the database connection after use
                } catch (SQLException e) {
                    // Handle the error, if any, during closing the connection
                    e.printStackTrace();
                }
            }
        }

        // 收件人邮箱地址
        // QQ邮箱授权码，不是QQ邮箱密码，请注意保密
        String password = (config.getString("senderPassword"));
        Lightning.getIns().getLogger().info(config.getString("email-sender"));
        // 发件人QQ邮箱地址
        String from = config.getString("email-sender");

        // QQ邮箱SMTP服务器地址
        String host = "smtp.qq.com";

        // 配置邮件服务器
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");
        properties.setProperty("mail.smtp.port", "587");


        // 获取Session对象
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            // 创建邮件消息
            Message message = new MimeMessage(session);

            // 设置发件人
            message.setFrom(new InternetAddress(from));


            // 设置收件人
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(sjr));

            // 设置邮件主题
            message.setSubject(config.getString("email-title"));

            // 设置邮件正文
            message.setText(config.getString("email-message") + code);

            // 发送邮件
            Transport.send(message);
            emali.player.sendMessage("§a" + config.getString("emailbindsuccessful"));

            System.out.println("邮件发送成功！");
            INSERT(uuid, sjr, code,player);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    private static void connecteddatabase() {
        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");
        try {
            // 加载MySQL驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 建立数据库连接
            connection = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
            Lightning.getIns().getLogger().info("MySQL connected!");
        } catch (ClassNotFoundException | SQLException e) {
            Lightning.getIns().getLogger().warning("Can't connect to MySQL: " + e.getMessage());
            Lightning.getIns().disablePlugin();
            return; // If connection fails, return immediately to avoid further execution
        }
    }

    private static void INSERT(UUID uuid, String email, String code ,Player player) {
        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");
        try {
            // 加载MySQL驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 建立数据库连接
            connection = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
            Lightning.getIns().getLogger().info("MySQL !");
        } catch (ClassNotFoundException | SQLException e) {
            Lightning.getIns().getLogger().warning("Can't connect mysql" + e.getMessage());
            Lightning.getIns().disablePlugin();
        }
        if (connection != null) {
            try {
                String query = "SELECT * FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, emali.player.getUniqueId().toString()); // Set the UUID value for the first placeholder
                ResultSet resultSet = statement.executeQuery();
                if (!resultSet.next()){
                    try {
                        String querya = "INSERT INTO playerinfo (uid, code,email) VALUES (?, ?,?)"; // Use '?' as placeholders for values
                        PreparedStatement statementa = connection.prepareStatement(querya);
                        statementa.setString(1, uuid.toString()); // Set the UUID value for the first placeholder
                        statementa.setString(2, code); // Set the code value for the second placeholder
                        statementa.setString(3, email); // Set the email value for the second placeholder

                        statementa.executeUpdate();
                        statementa.close(); // Close the PreparedStatement after use
                        Lightning.getIns().getLogger().info("UUID and code inserted into the database!");
                    } catch (SQLException e) {
                        Lightning.getIns().getLogger().warning("Failed to insert UUID and code into the database: " + e.getMessage());
                    } finally {
                        try {
                            connection.close(); // Close the database connection after use
                        } catch (SQLException e) {
                            // Handle the error, if any, during closing the connection
                            e.printStackTrace();
                        }
                    }
                }else {
                    try {
                        String querya = "UPDATE playerinfo SET code = ? WHERE uid = ?";
                        PreparedStatement statementa = connection.prepareStatement(querya);
                        statementa.setString(1, code); // 设置code
                        statementa.setString(2, player.getUniqueId().toString()); // 设置UUID
                        statementa.executeUpdate();
                        Lightning.getIns().getLogger().info("Password inserted into the database for UUID: " + player.getUniqueId());
                        player.sendMessage(config.getString("successful"));

                    } catch (SQLException e) {
                        Lightning.getIns().getLogger().warning("Failed to insert password into the database: " + e.getMessage());
                    }
                    try {
                        String querya = "UPDATE playerinfo SET email = ? WHERE uid = ?";
                        PreparedStatement statementa = connection.prepareStatement(querya);
                        statementa.setString(1, email); // 设置code
                        statementa.setString(2, player.getUniqueId().toString()); // 设置UUID
                        statementa.executeUpdate();
                        Lightning.getIns().getLogger().info("Password inserted into the database for UUID: " + player.getUniqueId());
                        player.sendMessage(config.getString("successful"));

                    } catch (SQLException e) {
                        Lightning.getIns().getLogger().warning("Failed to insert password into the database: " + e.getMessage());
                    }
                }

                resultSet.close(); // Close the ResultSet after use
                statement.close(); // Close the PreparedStatement after use
            } catch (SQLException e) {
                Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
            }
        }
    }
}