package felix.lightning.lightninglogin;

import felix.lightning.mail.email;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.Random;


public class emali implements CommandExecutor {
    public static Player player;
    private Connection connection;
    private String host, database, username, password;


    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] args) {
        FileConfiguration config = Lightning.getIns().getConfig();
        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");

        if (args.length > 0) {
            if (commandSender instanceof Player) {
                // 命令由玩家发送

                player = (Player) commandSender;
                String date = args[0];
                String code = generateVerificationCode(6);
                try {
                    email.main(date,code,player.getUniqueId(),player);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
                return true;

            }else {
                return false;
            }
        }

    return false;
    }


    public static void InDataBase(){

    }


    public static String generateVerificationCode(int length) {
        String characters = "1123456789";
        StringBuilder codeBuilder = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            char randomChar = characters.charAt(index);
            codeBuilder.append(randomChar);
        }

        return codeBuilder.toString();
    }
}
