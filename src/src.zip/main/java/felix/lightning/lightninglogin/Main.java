package felix.lightning.lightninglogin;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.RemoteServerCommandEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import java.sql.*;
import java.util.*;

public class Main implements Listener {
    private Connection connection;
    private String host, database, username, password;
    FileConfiguration config = Lightning.getIns().getConfig();
    public final static List<String> commandList =new ArrayList<>();
    public final static List<String> OnLogin = new ArrayList<>();

    @EventHandler
    public void quit(PlayerQuitEvent args) {
        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");
        Player player = args.getPlayer();
        connectToDatabase();

        if (connection != null) {
            try {
                String query = "SELECT flag FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, player.getUniqueId().toString()); // Set the UUID value for the first placeholder
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    int columnValue = resultSet.getInt("flag");
                    if (columnValue <= 0) {
                        Lightning.getIns().getLogger().info(String.valueOf(columnValue));
                        String uid = String.valueOf(player.getUniqueId());
                        Lightning.getIns().getLogger().info("正在删除uid为 " + uid + " 的记录");

                        // 使用DELETE查询来删除当前记录
                        String deleteQuery = "DELETE FROM playerinfo WHERE uid = ?";
                        PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
                        deleteStatement.setString(1, uid);
                        int rowsDeleted = deleteStatement.executeUpdate();
                        Lightning.getIns().getLogger().info("已删除 " + rowsDeleted + " 条uid为 " + uid + " 的记录");

                        deleteStatement.close();
                    }
                }
                resultSet.close(); // Close the ResultSet after use
                statement.close(); // Close the PreparedStatement after use
            } catch (SQLException e) {
                Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
            }
        }


    }

    private void connectToDatabase() {
        try {
            // 加载MySQL驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 建立数据库连接
            connection = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
            Lightning.getIns().getLogger().info("MySQL !");
        } catch (ClassNotFoundException | SQLException e) {
            Lightning.getIns().getLogger().warning("Can't connect mysql" + e.getMessage());
            Lightning.getIns().disablePlugin();
        }
    }


    @EventHandler
    public void OnJoin(PlayerJoinEvent date) {

        Player player = date.getPlayer();
        if (OnLogin.contains(player.getName())) {
            OnLogin.remove(player.getName());
        }
        double x = config.getDouble("Pos.x");
        double y = config.getDouble("Pos.y");
        double z = config.getDouble("Pos.z");
        Location loc = new Location(player.getWorld(), x, y, z);
        player.teleport(loc);
        player.setPlayerListName("§a【Logging】 " + player.getName());
        player.setDisplayName("§a【Logging】" + player.getName());

    }

    public static void RemovePlayer(Player player) {
        OnLogin.add(player.getName());
    }


    @EventHandler
    public void InventoryMoveItem(InventoryMoveItemEvent args) {
        args.setCancelled(true);
    }
    private void loadCommandsFromConfig() {
        FileConfiguration config = Lightning.getIns().getConfig();
        ConfigurationSection commandsSection = config.getConfigurationSection("disablecommand");
        if (commandsSection != null) {
            for (String commandName : commandsSection.getKeys(false)) {
                String commandValue = commandsSection.getString(commandName);

                commandList.add(commandValue);
            }
        }else {
            Lightning.getIns().getLogger().info("配置读取错误！");
        }
    }


    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (!OnLogin.contains(event.getPlayer().getName())) {
            String command = event.getMessage().substring(1); // Remove the leading "/"
            ConfigurationSection commandsSection = config.getConfigurationSection("disablecommand");
            if (commandsSection != null) {
                for (String commandName : commandsSection.getKeys(false)) {
                    String commandValue = commandsSection.getString(commandName);
                    if (command.startsWith(commandValue)) {
                        event.setCancelled(true);
                        event.getPlayer().sendMessage("This command is disabled!");
                        break; // Stop checking once a match is found
                    }
                }
            }
        }
    }

    @EventHandler
    public void OnMove(PlayerMoveEvent date) {
        Player player = date.getPlayer();
        if (!OnLogin.contains(player.getName())) {
            double x = config.getDouble("Pos.x");
            double y = config.getDouble("Pos.y");
            double z = config.getDouble("Pos.z");
            Location loc = new Location(player.getWorld(), x, y, z);
            player.teleport(loc);
            ItemStack customBook = new ItemStack(Material.WRITTEN_BOOK);
            BookMeta bookMeta = (BookMeta) customBook.getItemMeta();
            bookMeta.setTitle("§bWelcome Book");
            bookMeta.setAuthor("§cServer");
            bookMeta.addPage("§b" + config.getString("Bookpage1"));
            bookMeta.addPage("§c" + config.getString("Bookpage2"));
            player.sendMessage("§c===============================");
            player.sendMessage("§a" + config.getString("Message"));
            player.sendMessage("§c===============================");
            customBook.setItemMeta(bookMeta);
            // 将自定义的书本放入玩家的手中
            player.getInventory().setItem(0, customBook);
        }
    }

}
