package felix.lightning.lightninglogin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.Objects;

public class login implements CommandExecutor {
    private Connection connection;
    private String host, database, username, password;
    FileConfiguration config = Lightning.getIns().getConfig();

    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String str, String[] args) {
        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");
        connectToDatabase();
        Player player = (Player) commandSender;
        if (args.length > 0){
            if (connection != null) {

                try {
                    String query = "SELECT password FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, player.getUniqueId().toString()); // Set the UUID value for the first placeholder
                    ResultSet resultSet = statement.executeQuery();
                    if (resultSet.next()) {
                        String password = resultSet.getString("password");
                        if (Objects.equals(args[0], password)){
                            Main.RemovePlayer(player);
                            player.sendMessage("§a" + config.getString("login-message"));
                            return true;
                        }else {
                            player.sendMessage("§c" + config.getString("error-message"));
                            return true;
                        }

                    }

                    resultSet.close(); // Close the ResultSet after use
                    statement.close(); // Close the PreparedStatement after use
                } catch (SQLException e) {
                    Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
                }

            }
        }



        return true;
    }
    private void connectToDatabase() {
        try {
            // 加载MySQL驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 建立数据库连接
            connection = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
            Lightning.getIns().getLogger().info("MySQL !");
        } catch (ClassNotFoundException | SQLException e) {
            Lightning.getIns().getLogger().warning("Can't connect mysql" + e.getMessage());
            Lightning.getIns().disablePlugin();
        }
    }
}
