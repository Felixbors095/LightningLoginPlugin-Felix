package felix.lightning.lightninglogin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.Objects;

public class register implements CommandExecutor {

    private Connection connection;
    private String host, database, username, password;
    FileConfiguration config = Lightning.getIns().getConfig();

    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] args) {
        // 读取配置文件或者在这里设置MySQL连接参数


        host = config.getString("database.host");
        database = config.getString("database.database");
        username = config.getString("database.username");
        password = config.getString("database.password");

        if (commandSender instanceof Player) {
            Player player = (Player) commandSender;

            connectToDatabase();
            if (args.length < 2) {
                player.sendMessage(config.getString("cmdtips"));
                return true;
            } else {

                try {
                    String query = "SELECT flag FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, player.getUniqueId().toString()); // Set the UUID value for the first placeholder
                    ResultSet resultSet = statement.executeQuery();
                    while (resultSet.next()) {
                        // 使用 getter 方法从结果集中获取值
                        int columnValue = resultSet.getInt("flag");
                        if (columnValue > 0) {
                            Lightning.getIns().getLogger().info(String.valueOf(columnValue));
                            player.kickPlayer("§cYou Can't do it!");
                            return false;
                        }
                    }

                    resultSet.close(); // Close the ResultSet after use
                    statement.close(); // Close the PreparedStatement after use
                } catch (SQLException e) {
                    Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
                }

            }

            if (args.length >= 0) {
                String playerpassword = args[0];
                String code = args[1];
                if (connection != null) {
                    try {
                        String query = "SELECT code FROM playerinfo WHERE uid = ?"; // Use '?' as placeholders for values
                        PreparedStatement statement = connection.prepareStatement(query);
                        statement.setString(1, player.getUniqueId().toString()); // Set the UUID value for the first placeholder
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            // If the query returns a row, extract the 'code' column value
                            String sqlcode = resultSet.getString("code");
                            if (Objects.equals(code, sqlcode)) {

                                if (connection != null) {
                                    try {
                                        String querya = "UPDATE playerinfo SET password = ? WHERE uid = ?";
                                        PreparedStatement statementa = connection.prepareStatement(querya);
                                        statementa.setString(1, playerpassword); // 设置密码
                                        statementa.setString(2, player.getUniqueId().toString()); // 设置UUID
                                        statementa.executeUpdate();
                                        Lightning.getIns().getLogger().info("Password inserted into the database for UUID: " + player.getUniqueId());
                                        player.sendMessage(config.getString("successful"));

                                    } catch (SQLException e) {
                                        Lightning.getIns().getLogger().warning("Failed to insert password into the database: " + e.getMessage());
                                    }
                                }
                                if (connection != null) {
                                    try {
                                        String querya = "UPDATE playerinfo SET flag = ? WHERE uid = ?";
                                        PreparedStatement statementa = connection.prepareStatement(querya);
                                        statementa.setInt(1, 1); // 设置flag
                                        statementa.setString(2, player.getUniqueId().toString()); // 设置UUID
                                        statementa.executeUpdate();

                                    } catch (SQLException e) {
                                        Lightning.getIns().getLogger().warning("Failed to insert password into the database: " + e.getMessage());
                                    }
                                }


                            }
                        } else {
                            player.kickPlayer(config.getString("notindatabase"));
                            return false;
                        }

                        resultSet.close(); // Close the ResultSet after use
                        statement.close(); // Close the PreparedStatement after use
                    } catch (SQLException e) {
                        Lightning.getIns().getLogger().warning("Failed to query database: " + e.getMessage());
                    } finally {
                        try {
                            if (connection != null) {
                                connection.close(); // Close the database connection after use
                            }
                        } catch (SQLException e) {
                            // Handle the error, if any, during closing the connection
                            e.printStackTrace();
                        }
                    }
                }


            } else {
                player.sendMessage("§e================");
                player.sendMessage("§a" + config.getString("cmdtips"));
                player.sendMessage("§e================");

            }


        } else {
            return false;
        }
        return true;
    }



    private void closeConnection() {
        try {
            if (connection != null) {
                connection.close();
                Lightning.getIns().getLogger().info("MySQLClose！");
            }
        } catch (SQLException e) {
            Lightning.getIns().getLogger().warning("Closing MySQL Error：" + e.getMessage());
        }
    }

    private void connectToDatabase() {
        try {
            // 加载MySQL驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 建立数据库连接
            connection = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
            Lightning.getIns().getLogger().info("MySQL !");
        } catch (ClassNotFoundException | SQLException e) {
            Lightning.getIns().getLogger().warning("Can't connect mysql" + e.getMessage());
            Lightning.getIns().disablePlugin();
        }
    }
}
