package felix.lightning.lightninglogin;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class Lightning extends JavaPlugin {

/*    a
 @Felix
    a*/




    public final static List<String> OnLogin = new ArrayList<>();
    private static Lightning ins;

    public static Lightning getIns() {
        return ins;
    }
    public void disablePlugin(){
        Bukkit.getPluginManager().disablePlugin(this);
    }
    public static final String ANSI_RESET = "\u001B[0m";

    public static final String ANSI_GREEN = "\u001B[32m";


    @Override
    public void onEnable() {
        reConfig();
        ins = this; // 初始化 ins 对象
        getServer().getPluginManager().registerEvents(new Main(), this);
        getCommand("register").setExecutor(new register());
        getCommand("myemail").setExecutor(new emali());
        getCommand("login").setExecutor(new login());



        getLogger().info("【LightingLogin】 plugin load！");


        getLogger().info(ANSI_GREEN + "\n" +
                "    __    _       __    __  _             __               _     \n" +
                "   / /   (_____ _/ /_  / /_(_____  ____ _/ /  ____  ____ _(_____ \n" +
                "  / /   / / __ `/ __ \\/ __/ / __ \\/ __ `/ /  / __ \\/ __ `/ / __ \\\n" +
                " / /___/ / /_/ / / / / /_/ / / / / /_/ / /__/ /_/ / /_/ / / / / /\n" +
                "/_____/_/\\__, /_/ /_/\\__/_/_/ /_/\\__, /_____\\____/\\__, /_/_/ /_/ \n" +
                "        /____/                  /____/           /____/          \n" + ANSI_RESET);
    }
    public void reConfig(){
        saveDefaultConfig();
    }




    @Override
    public void onDisable() {


    }
}
